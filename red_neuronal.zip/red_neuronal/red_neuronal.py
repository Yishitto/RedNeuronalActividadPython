import numpy as np
import pandas as pd


def sigmoide(x):
    return 1 / (1 + np.exp(-x))


def derivada_sigmoide(x):
    return x * (1 - x)


np.random.seed(7)

entradas = np.array([[0, 0],
                     [0, 1],
                     [1, 0],
                     [1, 1]])

salidas = np.array([[0],
                    [1],
                    [1],
                    [0]])

neuronas_entrada = 2
neuronas_ocultas = 4
neuronas_salida = 1
tasa_aprendizaje = 0.5
epocas = 10000

pesos_oculta = np.random.uniform(-1, 1, (neuronas_entrada, neuronas_ocultas))
sesgo_oculta = np.zeros((1, neuronas_ocultas))
pesos_salida = np.random.uniform(-1, 1, (neuronas_ocultas, neuronas_salida))
sesgo_salida = np.zeros((1, neuronas_salida))

historial = []

for epoca in range(epocas):
    suma_oculta = np.dot(entradas, pesos_oculta) + sesgo_oculta
    activacion_oculta = sigmoide(suma_oculta)

    suma_salida = np.dot(activacion_oculta, pesos_salida) + sesgo_salida
    prediccion = sigmoide(suma_salida)

    error = salidas - prediccion
    perdida = np.mean(error ** 2)
    historial.append(perdida)

    delta_salida = error * derivada_sigmoide(prediccion)
    error_oculta = np.dot(delta_salida, pesos_salida.T)
    delta_oculta = error_oculta * derivada_sigmoide(activacion_oculta)

    pesos_salida += tasa_aprendizaje * np.dot(activacion_oculta.T, delta_salida)
    sesgo_salida += tasa_aprendizaje * np.sum(delta_salida, axis=0, keepdims=True)
    pesos_oculta += tasa_aprendizaje * np.dot(entradas.T, delta_oculta)
    sesgo_oculta += tasa_aprendizaje * np.sum(delta_oculta, axis=0, keepdims=True)

    if epoca % 1000 == 0:
        print("epoca", epoca, "perdida", round(perdida, 6))

print()
print("Resultados finales")
for i in range(len(entradas)):
    print(entradas[i], "->", round(float(prediccion[i][0]), 4), "esperado", salidas[i][0])

tabla_pesos_oculta = pd.DataFrame(pesos_oculta,
                                  index=["x1", "x2"],
                                  columns=["h1", "h2", "h3", "h4"])
tabla_sesgo_oculta = pd.DataFrame(sesgo_oculta, index=["sesgo"], columns=["h1", "h2", "h3", "h4"])
tabla_pesos_salida = pd.DataFrame(pesos_salida, index=["h1", "h2", "h3", "h4"], columns=["y"])
tabla_sesgo_salida = pd.DataFrame(sesgo_salida, index=["sesgo"], columns=["y"])

tabla_resultados = pd.DataFrame({
    "x1": entradas[:, 0],
    "x2": entradas[:, 1],
    "esperado": salidas[:, 0],
    "prediccion": prediccion[:, 0].round(4),
    "redondeado": prediccion[:, 0].round().astype(int)
})

tabla_perdida = pd.DataFrame({"epoca": range(0, epocas, 100), "perdida": historial[::100]})

with pd.ExcelWriter("pesos_red_neuronal.xlsx") as archivo:
    tabla_pesos_oculta.to_excel(archivo, sheet_name="pesos_capa_oculta")
    tabla_sesgo_oculta.to_excel(archivo, sheet_name="sesgo_capa_oculta")
    tabla_pesos_salida.to_excel(archivo, sheet_name="pesos_capa_salida")
    tabla_sesgo_salida.to_excel(archivo, sheet_name="sesgo_capa_salida")
    tabla_resultados.to_excel(archivo, sheet_name="resultados", index=False)
    tabla_perdida.to_excel(archivo, sheet_name="perdida", index=False)

print()
print("Pesos guardados en pesos_red_neuronal.xlsx")
