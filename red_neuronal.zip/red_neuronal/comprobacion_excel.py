from openpyxl import load_workbook

libro = load_workbook("pesos_red_neuronal.xlsx")
hoja = libro.create_sheet("comprobacion")

hoja["A1"] = "Comprobacion del calculo con los pesos guardados"
hoja["A3"] = "x1"
hoja["B3"] = "x2"
hoja["C3"] = "h1"
hoja["D3"] = "h2"
hoja["E3"] = "h3"
hoja["F3"] = "h4"
hoja["G3"] = "y"
hoja["H3"] = "esperado"

entradas = [(0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0)]
columnas_ocultas = ["B", "C", "D", "E"]

for i, (x1, x2, esperado) in enumerate(entradas):
    fila = 4 + i
    hoja[f"A{fila}"] = x1
    hoja[f"B{fila}"] = x2
    for j, col in enumerate(columnas_ocultas):
        celda = f"{'CDEF'[j]}{fila}"
        suma = f"A{fila}*pesos_capa_oculta!{col}2+B{fila}*pesos_capa_oculta!{col}3+sesgo_capa_oculta!{col}2"
        hoja[celda] = f"=1/(1+EXP(-({suma})))"
    suma_salida = (f"C{fila}*pesos_capa_salida!B2+D{fila}*pesos_capa_salida!B3"
                   f"+E{fila}*pesos_capa_salida!B4+F{fila}*pesos_capa_salida!B5+sesgo_capa_salida!B2")
    hoja[f"G{fila}"] = f"=1/(1+EXP(-({suma_salida})))"
    hoja[f"H{fila}"] = esperado

libro.save("pesos_red_neuronal.xlsx")
print("Hoja de comprobacion agregada")
