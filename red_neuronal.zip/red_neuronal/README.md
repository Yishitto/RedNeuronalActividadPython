# Red neuronal desde cero en Python

Implementación de una red neuronal multicapa sin librerías de machine learning,
usando únicamente NumPy para las operaciones con matrices. La red aprende la
compuerta lógica XOR, que no es linealmente separable y por eso necesita una
capa oculta.

## Arquitectura

- Capa de entrada: 2 neuronas (x1, x2)
- Capa oculta: 4 neuronas con activación sigmoide
- Capa de salida: 1 neurona con activación sigmoide
- Entrenamiento: descenso de gradiente con retropropagación
- Tasa de aprendizaje: 0.5
- Épocas: 10000

## Archivos

| Archivo | Descripción |
|---|---|
| `red_neuronal.py` | Entrena la red, imprime la pérdida y las predicciones, y guarda los pesos en Excel |
| `comprobacion_excel.py` | Agrega al Excel una hoja con fórmulas que recalculan la salida de la red usando los pesos guardados |
| `pesos_red_neuronal.xlsx` | Pesos y sesgos generados, resultados, historial de pérdida y hoja de comprobación |

## Cómo ejecutar

```bash
pip install numpy pandas openpyxl
python red_neuronal.py
python comprobacion_excel.py
```

## Resultados

| x1 | x2 | esperado | predicción |
|---|---|---|---|
| 0 | 0 | 0 | 0.0156 |
| 0 | 1 | 1 | 0.9837 |
| 1 | 0 | 1 | 0.9841 |
| 1 | 1 | 0 | 0.0155 |

## Comprobación en Excel

El archivo `pesos_red_neuronal.xlsx` tiene las hojas:

- `pesos_capa_oculta` y `sesgo_capa_oculta`: pesos de la entrada a la capa oculta
- `pesos_capa_salida` y `sesgo_capa_salida`: pesos de la capa oculta a la salida
- `resultados`: predicciones obtenidas en Python
- `perdida`: error cuadrático medio cada 100 épocas
- `comprobacion`: calcula con fórmulas de Excel la salida de cada neurona a partir
  de los pesos guardados, para verificar que coincide con lo que entrega Python
